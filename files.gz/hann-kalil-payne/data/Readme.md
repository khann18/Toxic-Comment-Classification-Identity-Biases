To download our training and testing data, go to 
https://www.kaggle.com/c/jigsaw-unintended-bias-in-toxicity-classification/data?select=test.csv
and download `train.csv`, `test_private_expanded.csv`, and `test_public_expanded.csv`.
These files will be used in both of our other ReadMe's. 