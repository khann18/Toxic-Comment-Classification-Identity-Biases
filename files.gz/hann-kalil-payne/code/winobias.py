from detoxify import Detoxify 
import numpy as np 

model = Detoxify("unbiased")
pro_stereotypical = []
anti_stereotypical = []

pro_men = []
anti_women = []
pro_women = []
anti_men = []

pro_scores = []
anti_scores = []
pro_obscene = []
anti_obscene = []
pro_insult = []
anti_insult = []
pro_threat = []
anti_threat = []
pro_ident = []
anti_ident = []
pro_sexual = []
anti_sexual = []

for line in open("pro_stereotyped_type1.txt.test", "r"):
	pro_stereotypical.append(line.strip().replace("[", "").replace("]", ""))
	if "[he]" in line or "[his]" in line or "[him]" in line: 
		pro_men.append(line.strip().replace("[", "").replace("]", ""))
	elif "[she]" in line or "[her]" in line or "[hers]" in line:
		pro_women.append(line.strip().replace("[", "").replace("]", ""))
for line in open("anti_stereotyped_type1.txt.test", "r"):
	anti_stereotypical.append(line.strip().replace("[", "").replace("]", ""))
	if "[he]" in line or "[his]" in line or "[him]" in line: 
		anti_men.append(line.strip().replace("[", "").replace("]", ""))
	elif "[she]" in line or "[her]" in line or "[hers]" in line:
		anti_women.append(line.strip().replace("[", "").replace("]", ""))
for line in open("pro_stereotyped_type2.txt.test", "r"):
	pro_stereotypical.append(line.strip().replace("[", "").replace("]", ""))
	if "[he]" in line or "[his]" in line or "[him]" in line: 
		pro_men.append(line.strip().replace("[", "").replace("]", ""))
	elif "[she]" in line or "[her]" in line or "[hers]" in line:
		pro_women.append(line.strip().replace("[", "").replace("]", ""))
for line in open("anti_stereotyped_type2.txt.test", "r"):
	anti_stereotypical.append(line.strip().replace("[", "").replace("]", ""))
	if "[he]" in line or "[his]" in line or "[him]" in line: 
		anti_men.append(line.strip().replace("[", "").replace("]", ""))
	elif "[she]" in line or "[her]" in line or "[hers]" in line:
		anti_women.append(line.strip().replace("[", "").replace("]", ""))
print(len(anti_stereotypical), len(pro_women), len(pro_men))
for i in range(len(anti_stereotypical)):
	if anti_stereotypical[i].split(" ")[0] == pro_stereotypical[i].split(" ")[0]:
		print(anti_stereotypical[i], pro_stereotypical[i])
		pro_women_predict = model.predict(pro_stereotypical[i])
		anti_men_predict = model.predict(anti_stereotypical[i])
		pro_scores.append(pro_women_predict["toxicity"])
		anti_scores.append(anti_men_predict["toxicity"])
		pro_obscene.append(pro_women_predict["obscene"])
		anti_obscene.append(anti_men_predict["obscene"])
		pro_insult.append(pro_women_predict["insult"])
		anti_insult.append(anti_men_predict["insult"])
		pro_threat.append(pro_women_predict["threat"])
		anti_threat.append(anti_men_predict["threat"])
		pro_ident.append(pro_women_predict["identity_attack"])
		anti_ident.append(anti_men_predict["identity_attack"])
		pro_sexual.append(pro_women_predict["sexual_explicit"])
		anti_sexual.append(anti_men_predict["sexual_explicit"])



print("TOXICITY")
pro_scores = np.asarray(pro_scores)
print("pro", np.mean(pro_scores), np.std(pro_scores))
anti_scores = np.asarray(anti_scores)
print("anti", np.mean(anti_scores), np.std(anti_scores))
x = [1 for i in range(len(anti_scores)) if anti_scores[i] > pro_scores[i]]
print("percent anti stereotypical more toxic than pro-stereotypical", sum(x)/ len(anti_scores))
	#print(model.predict(pro_stereotypical[i])["toxicity"], model.predict(anti_stereotypical[i])["toxicity"])

print("OBSCENE")
pro_obscene = np.asarray(pro_obscene)
print("pro", np.mean(pro_obscene), np.std(pro_obscene))
anti_obscene = np.asarray(anti_obscene)
print("anti", np.mean(anti_obscene), np.std(anti_obscene))
x = [1 for i in range(len(anti_obscene)) if anti_obscene[i] > pro_obscene[i]]
print("percent anti stereotypical more toxic than pro-stereotypical", sum(x)/ len(anti_scores))

print("INSULT")
pro_insult = np.asarray(pro_insult)
print("pro", np.mean(pro_insult), np.std(pro_insult))
anti_insult = np.asarray(anti_insult)
print("anti", np.mean(anti_insult), np.std(anti_insult))
x = [1 for i in range(len(anti_insult)) if anti_insult[i] > pro_insult[i]]
print("percent anti stereotypical more toxic than pro-stereotypical", sum(x)/ len(anti_scores))


print("THREAT")
pro_threat = np.asarray(pro_threat)
print("pro", np.mean(pro_threat), np.std(pro_threat))
anti_threat = np.asarray(anti_threat)
print("anti", np.mean(anti_threat), np.std(anti_threat))
x = [1 for i in range(len(anti_threat)) if anti_threat[i] > pro_threat[i]]
print("percent anti stereotypical more toxic than pro-stereotypical", sum(x)/ len(anti_scores))
# "obscene", "insult", "threat", "identity_attack", "sexual_explicit"

print("identity_attack")
pro_ident = np.asarray(pro_ident)
print("pro", np.mean(pro_ident), np.std(pro_ident))
anti_ident = np.asarray(anti_ident)
print("anti", np.mean(anti_ident), np.std(anti_ident))
x = [1 for i in range(len(anti_ident)) if anti_ident[i] > pro_ident[i]]
print("percent anti stereotypical more toxic than pro-stereotypical", sum(x)/ len(anti_scores))

print("sexual_explicit")
pro_sexual = np.asarray(pro_sexual)
print("pro", np.mean(pro_sexual), np.std(pro_sexual))
anti_sexual = np.asarray(anti_sexual)
print("anti", np.mean(anti_sexual), np.std(anti_sexual))
x = [1 for i in range(len(anti_sexual)) if anti_sexual[i] > pro_sexual[i]]
print("percent anti stereotypical more toxic than pro-stereotypical", sum(x)/ len(anti_scores))