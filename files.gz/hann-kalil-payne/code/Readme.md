`compute_aeg.py`: computes AEG, takes in two mandatory arguments and one optional argument.
The first arguments gives the path to the output CSV you wish to evaluate (either of the files
we provide in `outputs`), and the second argument specifies the type of AEG you wish to compute,
either `positive` or `negative.` An optional parameter changes the threshold for something to be 
considered a positive example; this value is by default 0.5 but may be set by a third argument 
`--threshold=threshold`. To run, run `python3 full/path/to/file positive/negative (threshold).`

`compute_bnsp_bpsn.py`: computes BPSN and BNSP AUC, with the same arguments as above, except that 
the second indicates which type of AUC and is thus either `bpsn` or `bnsp.`

`general_auc.py`: computes the overall AUC for each toxicity category. It takes in a single argument to the output file (either of those provided in `outputs`) and an 
optional tunable threshold parameter as above. 

`subgroup_auc.py`: computes subgroup AUC and takes in an argument indicating the path to the output file and 
an optional tunable threshold parameter as above. To run, run `python3 subgroup_auc.py /path/to/file`

`create_fuzzed_notebook.ipynb`: contains the code to create the fuzzed comments, and may be run on Jupyter. 

`process_data.py`: contains the code to run the model over the testing data. To run, place in a directory with 
the two test sets (`test_private_expanded.csv` and `test_public_expanded.csv`) and run `python3 process_data.py`. 

`threshold.py`: computes the distribution of the scores in the training data. To run, place in a directory with `train.csv` and run
`python3 threshold.py`. 

`winobias.py`: performs evaluation on the WinoBias data. To run, place in a directory with the WinoBias `anti_stereotype` and `pro_stereotype` test
sets provided and run `python3 winobias.py`. The code is currently configured to give results over all examples, but that can be changed
by swapping `anti_stereotypical` and `pro_stereotypical` on lines 51-53 with other examples such as `pro_male` and `anti_female` to contrast 
pro-stereotypical sentences using male pronouns and anti-stereotypical ones using female pronouns. 
