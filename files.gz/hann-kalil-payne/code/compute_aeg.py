import pandas as pd 
import numpy as np
from sklearn import metrics
import matplotlib
from matplotlib import cm
import matplotlib.pyplot as plt
from matplotlib import colors 
import argparse
import scipy.stats as stats


toxic_labels = ["toxicity", "obscene", "insult", "threat", "identity_attack", "sexual_explicit"]
identity_words = ["male", "female", "transgender","heterosexual", "homosexual_gay_or_lesbian", "christian", "jewish", "muslim", "atheist", "black", "white", "asian", "latino","psychiatric_or_mental_illness", ]


def aeg_helper(background, subgroup, toxicity_type, threshold):
	"""Helper function that calculates the AUC on a given matrix"""
	# get and binarize the true predictions
	bg = np.asarray(background["predicted_"+toxicity_type])
	# bg[bg >= threshold] = 1
	# bg[bg < threshold] = 0

	sub = np.asarray(subgroup["predicted_"+toxicity_type])
	# sub[sub >= threshold] = 1
	# sub[sub < threshold] = 0
	# get the predictions 
	# return the AUC score over the positive background and negative subgroup
	# if len(sub) == 0 or len(bg) == 0:
	# 	return 0
	aeg = (0.5 - (stats.mannwhitneyu(bg, sub, alternative='less')[0]) / (len(sub) * len(bg)))
	return aeg



def compute_positive_aeg(df, identity, threshold, toxicity_type):
	"""Computes AUC over positive background and negative subgroup"""
	# positive background: the identity must be less than the threshold and the toxicity should be greater
	plus_background = df[(df[identity] < threshold) & (df[toxicity_type] >= threshold)]
	# positive subgroup: the identity must be greater than the threshold and the toxicity should be greater as well
	plus_subgroup = df[(df[identity] >= threshold) & (df[toxicity_type] >= threshold)]

	return aeg_helper(plus_background, plus_subgroup, toxicity_type, threshold)
	

def compute_negative_aeg(df, identity, threshold, toxicity_type):
	"""Computes AUC over negative background and positive subgroup"""
	# negative background: the identity must be less than the threshold and the toxicity should be less as well
	minus_background = df[(df[identity] < threshold) & (df[toxicity_type] < threshold)]
	# negative subgroup: the identity must be greater than the threshold and the toxicity should be less
	minus_subgroup = df[(df[identity] >= threshold) & (df[toxicity_type] < threshold)]

	return aeg_helper(minus_background, minus_subgroup, toxicity_type, threshold)

def main():
	"""Controls the main execution and parsing of commandline args"""

	# parse the user's arguments
	parser = argparse.ArgumentParser(description='Get command line arguments')
	parser.add_argument('filename', type=str, help='The path to the csv file containing the data')
	parser.add_argument('AEG', type=str, help="The type of AEG to use: positive or negative")
	parser.add_argument('--threshold', type=float, help='Threshold for predictions to be considered as positive class', default=0.5)#0.00000001)
	args = parser.parse_args()
	# read in the csv file that the user inputs
	df = pd.read_csv(args.filename)
	df = df[df['id'] > 0]

	# calculate all of the AUCs based on the user's arguments
	AEG_dict = {}
	for toxicity in toxic_labels:
		AEG_dict[toxicity] = {}
		for identity in identity_words:
			if args.AEG.lower() == 'positive':
				AEG_dict[toxicity][identity] = compute_positive_aeg(df, identity, args.threshold, toxicity)
			elif args.AEG.lower() == 'negative':
				AEG_dict[toxicity][identity] = compute_negative_aeg(df, identity, args.threshold, toxicity)
			else: 
				raise RuntimeError("Invalid AUC specified")

	print(AEG_dict)

	# make the DataFrame for the heatmap
	for key in AEG_dict:
		print(key, AEG_dict[key])
	df_to_graph = pd.DataFrame.from_dict(AEG_dict)
	fig, ax = plt.subplots()
	# colour the plot so that the ones we couldn't calculate are in black
	viridis = cm.get_cmap('viridis_r', 256)
	newcolors = viridis(np.linspace(0, 1, 256))
	newcmp = colors.ListedColormap(newcolors)
	#plot the heat map and add axis labels
	im = ax.imshow(df_to_graph, cmap=newcmp)
	ax.set_xticks(np.arange(len(toxic_labels)))
	ax.set_yticks(np.arange(len(identity_words)))
	ax.set_xticklabels(toxic_labels)
	ax.set_yticklabels(identity_words)
	plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
         rotation_mode="anchor")
	# add the legend to the plot
	cbar = ax.figure.colorbar(im, ax=ax)
	cbar.ax.set_ylabel(args.AEG + " AEG score", rotation=-90, va="bottom")
	ax.set_title(args.AEG.upper() +" AEG, threshold = " +str(args.threshold)) # = "TITLE IS HERE"
	plt.show()


if __name__ == '__main__':
	main()