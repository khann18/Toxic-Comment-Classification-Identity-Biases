import pandas as pd 
import numpy as np
from scipy.stats import pearsonr
import matplotlib
from matplotlib import cm
import matplotlib.pyplot as plt
from matplotlib import colors 


toxic_labels = ["obscene", "insult", "threat", "identity_attack", "sexual_explicit"]
identity_words = ["male", "female", "transgender","heterosexual", "homosexual_gay_or_lesbian", "christian", "jewish", "muslim", "atheist", "black", "white", "asian", "latino","psychiatric_or_mental_illness", ]

# private_test = pd.read_csv("test_private_expanded.csv")
# public_test = pd.read_csv("test_public_expanded.csv")
# training_data = pd.concat([private_test, public_test], ignore_index=True)
# training_data = training_data.reset_index()
#training_data = pd.read_csv("unbiased_predictions_v2.csv")
training_data = pd.read_csv("train.csv")
training_data = training_data.dropna().copy()
print(training_data.shape)

correlation_dict = {}
for toxic_label in toxic_labels:
	correlation_dict[toxic_label] = {}
	for identity_word in identity_words:
		print(np.mean(training_data[toxic_label]), np.mean(training_data[toxic_label]))
		correlation_dict[toxic_label][identity_word] = pearsonr(training_data[toxic_label], training_data[identity_word])[0]

df_to_graph = pd.DataFrame.from_dict(correlation_dict)
fig, ax = plt.subplots()
im = ax.imshow(df_to_graph)
ax.set_xticks(np.arange(len(toxic_labels)))
ax.set_yticks(np.arange(len(identity_words)))
ax.set_xticklabels(toxic_labels)
ax.set_yticklabels(identity_words)
plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
         rotation_mode="anchor")
# add the legend to the plot
cbar = ax.figure.colorbar(im, ax=ax)
cbar.ax.set_ylabel("Pearson r Correlation", rotation=-90, va="bottom")
ax.set_title("Training Correlation between Annotations of Identity Words and Toxicity Categories")
plt.show()
