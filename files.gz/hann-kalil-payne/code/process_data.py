import pandas as pd 
import numpy as np
import math
from detoxify import Detoxify

# load in the private and public test files, and concatenate them
print("Loading data ...")
private_test = pd.read_csv("test_private_expanded.csv")
all_test = private_test
public_test = pd.read_csv("test_public_expanded.csv")
all_test = pd.concat([private_test, public_test], ignore_index=True)


# drop anything for which we don't have MTurk information about content
all_test = all_test.dropna().copy()
#create columns for our predictions
all_test['predicted_toxicity'] = np.zeros(all_test.shape[0])
all_test['predicted_severe_toxicity'] = np.zeros(all_test.shape[0])
all_test['predicted_obscene'] = np.zeros(all_test.shape[0])
all_test['predicted_identity_attack'] = np.zeros(all_test.shape[0])
all_test['predicted_insult'] = np.zeros(all_test.shape[0])
all_test['predicted_threat'] = np.zeros(all_test.shape[0])
all_test['predicted_sexual_explicit'] = np.zeros(all_test.shape[0])

print("Data loaded. Loading model...")

#get the model
model = Detoxify('unbiased')
print("Model loaded. Making predictions...")
all_test = all_test.reset_index()
print(all_test.shape)

#make the comments into a list and get model predictions
comments = np.asarray(all_test.comment_text)
for i in range(all_test.shape[0]):
	if i %500 == 0:
		print(f"{i} predictions made...")
		print(all_test.shape)
	predictions = model.predict(comments[i])
	for predict in predictions:
		all_test.loc[i, 'predicted_'+predict] = predictions[predict]

#write out to CSV
print(all_test.shape)
print("Finished. Writing result to \'testing_predictions.csv\'")
all_test.to_csv("test_predictions.csv")

