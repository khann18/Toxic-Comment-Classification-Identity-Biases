import pandas as pd 
import numpy as np 
import math
import matplotlib.pyplot as plt

toxic_labels = ["obscene", "insult", "threat", "identity_attack", "sexual_explicit"]

line_colours = ["red", "blue", "green", "black", "purple"]	

def round_up(n, decimals=0):
    multiplier = 10 ** decimals
    return round(n * multiplier) / multiplier

df = pd.read_csv("train.csv")
df = df.dropna().copy()
for i in range(len(toxic_labels)):
	array = np.asarray(df[toxic_labels[i]])
	array = np.asarray([round_up(xi, 1) for xi in array])
	tenths_counts = {}
	for xi in array:
		if xi not in tenths_counts:
			tenths_counts[xi] = 1
		else: 
			tenths_counts[xi] += 1
	tenths = [np.log(val) for k, val in sorted(tenths_counts.items(), key=lambda x: x[0])]
	x = [k for k, val in sorted(tenths_counts.items(), key=lambda x: x[0])]
	print(x)
	print(tenths)
	plt.plot(x, tenths, color =line_colours[i])


plt.legend(toxic_labels)
plt.title("Frequency of Rounded Toxicity Scores")
plt.xlabel("Annotators' Score")
plt.ylabel("Log Frequency of Score")
plt.show()
