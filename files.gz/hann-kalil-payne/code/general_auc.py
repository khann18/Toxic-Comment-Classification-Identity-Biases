import pandas as pd
import numpy as np
from sklearn import metrics
import argparse


def main():
	parser = argparse.ArgumentParser(description='Get command line arguments')
	parser.add_argument('filename', type=str,
						help='The path to the csv file containing the data')
	parser.add_argument('--threshold', type=float,
						help='Threshold for predictions to be considered as positive class',
						default=0.5)
	args = parser.parse_args()
	threshold = args.threshold
	df = pd.read_csv(args.filename)
	for toxicity in ["toxicity", "obscene", "insult", "threat", "identity_attack", "sexual_explicit"]:
		y_true = np.asarray(df[toxicity])
		y_true[y_true >= threshold] = 1
		y_true[y_true < threshold] = 0
		print(toxicity, metrics.roc_auc_score(y_true, df["predicted_" + toxicity]))

if __name__ == '__main__':
	main()