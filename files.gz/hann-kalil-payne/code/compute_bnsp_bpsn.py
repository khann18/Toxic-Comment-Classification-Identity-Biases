import pandas as pd 
import numpy as np
from sklearn import metrics
import matplotlib
from matplotlib import cm
import matplotlib.pyplot as plt
from matplotlib import colors 
import argparse

toxic_labels = ["toxicity", "obscene", "insult", "threat", "identity_attack", "sexual_explicit"]
identity_words = ["male", "female", "transgender","heterosexual", "homosexual_gay_or_lesbian", "christian", "jewish", "muslim", "atheist", "black", "white", "asian", "latino","psychiatric_or_mental_illness", ]


def auc_helper(examples, toxicity_type, threshold):
	"""Helper function that calculates the AUC on a given matrix"""
	# get and binarize the true predictions
	y_true = np.asarray(examples[toxicity_type])
	y_true[y_true >= threshold] = 1
	y_true[y_true < threshold] = 0
	# get the predictions 
	y_pred = np.asarray(examples["predicted_"+toxicity_type])
	# return the AUC score over the positive background and negative subgroup
	try: 
		return metrics.roc_auc_score(y_true, y_pred)
	except:
		return float('nan')


def compute_bpsn_auc(df, identity, threshold, toxicity_type):
	"""Computes AUC over positive background and negative subgroup"""
	if df[df[identity] >= threshold].shape[0] < 100:
		return float('nan')
	# positive background: the identity must be less than the threshold and the toxicity should be greater
	plus_background = df[(df[identity] < threshold) & (df[toxicity_type] >= threshold)]
	# negative subgroup: the identity must be greater than the threshold and the toxicity should be less
	minus_subgroup = df[(df[identity] >= threshold) & (df[toxicity_type] < threshold)]
	# concat these together and calculate the AUC
	examples = pd.concat([plus_background, minus_subgroup])
	return auc_helper(examples, toxicity_type, threshold)
	

def compute_bnsp_auc(df, identity, threshold, toxicity_type):
	"""Computes AUC over negative background and positive subgroup"""
	if df[df[identity] >= threshold].shape[0] < 100:
		return float('nan')
	# negative background: the identity must be less than the threshold and the toxicity should be less as well
	minus_background = df[(df[identity] < threshold) & (df[toxicity_type] < threshold)]
	# positive subgroup: the identity must be greater than the threshold and the toxicity should be greater as well
	plus_subgroup = df[(df[identity] >= threshold) & (df[toxicity_type] >= threshold)]
	# concat these and calculate the AUC
	examples = pd.concat([minus_background, plus_subgroup])
	return auc_helper(examples, toxicity_type, threshold)

def main():
	"""Controls the main execution and parsing of commandline args"""

	# parse the user's arguments
	parser = argparse.ArgumentParser(description='Get command line arguments')
	parser.add_argument('filename', type=str, help='The path to the csv file containing the data')
	parser.add_argument('AUC', type=str, help="The type of AUC to use: BPSN or BNSP")
	parser.add_argument('--threshold', type=float, help='Threshold for predictions to be considered as positive class', default=0.5)
	args = parser.parse_args()
	# read in the csv file that the user inputs
	df = pd.read_csv(args.filename)

	# calculate all of the AUCs based on the user's arguments
	AUC_dict = {}
	other_dict = {}
	for toxicity in toxic_labels:
		#print(toxicity, auc_helper(df, toxicity, args.threshold))
		AUC_dict[toxicity] = {}
		for identity in identity_words:
			if args.AUC.lower() == 'bpsn':
				AUC_dict[toxicity][identity] = compute_bpsn_auc(df, identity, args.threshold, toxicity)
				other_dict[toxicity+" "+identity] = compute_bpsn_auc(df, identity, args.threshold, toxicity)
			elif args.AUC.lower() == 'bnsp':
				AUC_dict[toxicity][identity] = compute_bnsp_auc(df, identity, args.threshold, toxicity)
				other_dict[toxicity+" "+identity] = compute_bnsp_auc(df, identity, args.threshold, toxicity)
			else: 
				raise RuntimeError("Invalid AUC specified")

	# make the DataFrame for the heatmap
	df_to_graph = pd.DataFrame.from_dict(AUC_dict)
	fig, ax = plt.subplots()
	# colour the plot so that the ones we couldn't calculate are in black
	viridis = cm.get_cmap('viridis_r', 256)
	newcolors = viridis(np.linspace(0, 1, 256))
	newcmp = colors.ListedColormap(newcolors)
	#plot the heat map and add axis labels
	im = ax.imshow(df_to_graph, cmap=newcmp)
	ax.set_xticks(np.arange(len(toxic_labels)))
	ax.set_yticks(np.arange(len(identity_words)))
	ax.set_xticklabels(toxic_labels)
	ax.set_yticklabels(identity_words)
	plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
         rotation_mode="anchor")
	# add the legend to the plot
	cbar = ax.figure.colorbar(im, ax=ax)
	cbar.ax.set_ylabel(args.AUC + " AUC score", rotation=-90, va="bottom")
	ax.set_title(args.AUC.upper() +" AUC, threshold = " +str(args.threshold)) # = "TITLE IS HERE"
	plt.show()
	print({k: v for k, v in sorted(other_dict.items(), key=lambda x: x[1])})


if __name__ == '__main__':
	main()