import pandas as pd 
import numpy as np
from sklearn import metrics
import matplotlib
from matplotlib import cm
import matplotlib.pyplot as plt
from matplotlib import colors 
import argparse
import seaborn as sns

toxic_labels = ["toxicity", "obscene", "insult", "threat", "identity_attack", "sexual_explicit"]
identity_words = ["male", "female", "transgender","heterosexual", "homosexual_gay_or_lesbian", "christian", "jewish", "muslim", "atheist", "black", "white", "asian", "latino","psychiatric_or_mental_illness", ]


def auc_helper(examples, toxicity_type, threshold, identity):
    """Helper function that calculates the AUC on a given matrix"""
    # get and binarize the true predictions
    y_true = np.asarray(examples[toxicity_type])
    y_true[y_true >= threshold] = 1
    y_true[y_true < threshold] = 0
    # get the predictions 
    y_pred = np.asarray(examples["predicted_"+toxicity_type])
    try:
        score = metrics.roc_auc_score(y_true, y_pred)
        return score
    except Exception as e:
        return 0


def compute_subgroup_auc(df, identity, threshold, toxicity_type):
    plus_subgroup = df[(df[identity] >= threshold) & (df[toxicity_type] >= threshold)]
    minus_subgroup = df[(df[identity] >= threshold) & (df[toxicity_type] < threshold)]

    examples = pd.concat([plus_subgroup, minus_subgroup])
    return auc_helper(examples, toxicity_type, threshold, identity)

def main():
    parser = argparse.ArgumentParser(description='Get command line arguments')
    parser.add_argument('filename', type=str,
                        help='The path to the csv file containing the data')
    parser.add_argument('--threshold', type=float,
                        help='Threshold for predictions to be considered as positive class',
                        default=0.5)
    args = parser.parse_args()
    df = pd.read_csv(args.filename)
    AUC_dict = {}
    for toxicity in toxic_labels:
      AUC_dict[toxicity] = {}
      for identity in identity_words:
          AUC_dict[toxicity][identity] = compute_subgroup_auc(df, identity, args.threshold, toxicity)

    df_to_graph = pd.DataFrame.from_dict(AUC_dict)
    sns.heatmap(df_to_graph, square=True)
    plt.title("Subgroup AUC, threshold = 0.5")
    plt.savefig('subgroup_auc_heatmap')
    plt.show()


if __name__ == '__main__':
    main()