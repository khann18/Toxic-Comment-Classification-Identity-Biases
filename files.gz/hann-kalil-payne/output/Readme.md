To run evaluation on the outputs using the Borkan et al evaluation metrics, you 
will need to run one of the following three scripts: 

`compute_aeg.py`: computes AEG, takes in two mandatory arguments and one optional argument.
The first arguments gives the path to the output CSV you wish to evaluate (either of the files
we provide in `outputs`), and the second argument specifies the type of AEG you wish to compute,
either `positive` or `negative.` An optional parameter changes the threshold for something to be 
considered a positive example; this value is by default 0.5 but may be set by a third argument 
`--threshold=threshold`. To run, run `python3 full/path/to/file positive/negative (threshold).`

`compute_bnsp_bpsn.py`: computes BPSN and BNSP AUC, with the same arguments as above, except that 
the second indicates which type of AUC and is thus either `bpsn` or `bnsp.`

`subgroup_auc.py`: computes subgroup AUC and takes in an argument indicating the path to the output file and 
an optional tunable threshold parameter as above. To run, run `python3 subgroup_auc.py /path/to/file`

You may also run `general_auc.py`, with the same command-line arguments as `subgroup_auc.py`, to calculate general AUC 
scores on either file. 

To reproduce the WinoBias results, you will need only `winobias.py` and the corresponding `pro_stereotype` and 
`anti_stereotype` files from `data.`  To run, place in a directory with the WinoBias `anti_stereotype` and `pro_stereotype` test
sets provided and run `python3 winobias.py`. The code is currently configured to give results over all examples, but that can be changed
by swapping `anti_stereotypical` and `pro_stereotypical` on lines 51-53 with other examples such as `pro_male` and `anti_female` to contrast 
pro-stereotypical sentences using male pronouns and anti-stereotypical ones using female pronouns. 